#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_STATES 10
#define MAX_NAME_LENGTH 2
#define MAX_NEXT_STATES 10

//use struct to group variables of different types
struct State {
    char name[MAX_NAME_LENGTH];
    int num_state;
    struct State* next_states[MAX_NEXT_STATES];
    int num_next_states;
};

struct StateMachine {
    struct State* states[MAX_STATES];
    int num_states;
    struct State* current_state;
};

/*dynamically allocates memory for a new State struct, initializes its name, and sets the number of its next states to 0.*/
struct State* create_state(char* name) {
    struct State* new_state = (struct State*)malloc(sizeof(struct State));
    strcpy(new_state->name, name);
    new_state->num_next_states = 0;
    return new_state;
}

/* adds a new state to the array of next states of a given state.*/
void add_next_state(struct State* state, struct State* next_state) {
    state->next_states[state->num_next_states] = next_state;
    state->num_next_states++;
}

/*dynamically allocates memory for a new StateMachine struct, initializes its number of states to 0, and sets the current state to NULL.*/
struct StateMachine* create_state_machine() {
    struct StateMachine* new_state_machine = (struct StateMachine*)malloc(sizeof(struct StateMachine));
    new_state_machine->num_states = 0;
    new_state_machine->current_state = NULL;
    return new_state_machine;
}

/*adds a new state to the array of states of a given state machine.*/
void add_state(struct StateMachine* state_machine, struct State* state) {
    state_machine->states[state_machine->num_states] = state;
    state_machine->num_states++;
}

/*returns a pointer to a State struct with the specified name from a given StateMachine struct.*/
struct State* find_state(struct StateMachine* state_machine, char* name) {
    for (int i = 0; i < state_machine->num_states; i++) {
        if (strcmp(state_machine->states[i]->name, name) == 0) {
            return state_machine->states[i];
        }
    }
    return NULL;
}

/*changes the current state of a given StateMachine struct to a new state with a specified name.*/
void change_state_command(struct StateMachine* state_machine, char* name) {
    struct State* new_state = find_state(state_machine, name);
    if (new_state == NULL) {
        printf("Not %s\n", name);
    } else {
        state_machine->current_state = new_state;
    }
}

/*identifies and returns the number of unreachable states (garbage) in a given StateMachine struct. It uses a modified depth-first search algorithm*/
int identify_garbage_states_command(struct StateMachine* state_machine, struct State* garbage[MAX_STATES]) {
    int reachable[state_machine->num_states];
    for (int i = 0; i < state_machine->num_states; i++) {
        reachable[i] = 0;
    }
    int num_reachable = 0;
    struct State* initial_state = state_machine->current_state;

    reachable[initial_state->num_state] = 1;
    num_reachable++;

    int changed = 1;
    while (changed) {
        changed = 0;
        for (int i = 0; i < state_machine->num_states; i++) {
            if (reachable[i]) {
                struct State* state = state_machine->states[i];
                for (int j = 0; j < state->num_next_states; j++) {
                    int index = -1;
                    for (int k = 0; k < state_machine->num_states; k++) {
                        if (state_machine->states[k] == state->next_states[j]) {
                            index = k;
                            break;
                        }
                    }
                    if (index >= 0 && !reachable[index]) {
                        reachable[index] = 1;
                        num_reachable++;
                        changed = 1;
                    }
                }
            }
        }
    }

    int num_garbage = 0;

    for (int i = 0; i < state_machine->num_states; i++) {
        if (!reachable[i]) {
            garbage[num_garbage++] = state_machine->states[i];
        }
    }

    change_state_command(state_machine, initial_state->name);
    return num_garbage;
}

/*deletes the specified states from a given StateMachine struct.
It updates the array of next states of all states in the state machine to remove the deleted states,
shifts the remaining states in the array of states,
updates their indices, and frees the memory of the deleted states.*/
void delete_state_command(struct StateMachine* state_machine, struct State* garbage[MAX_STATES], int num_garbage) {
    for (int i = 0; i < num_garbage; i++) {
        struct State* state_to_delete = garbage[i];
        if (state_to_delete == NULL) {
            printf("No %s\n", garbage[i]->name);
        } else {
            printf("Deleted: %s\n", state_to_delete->name);
            for (int i = 0; i < state_machine->num_states; i++) {
                struct State* state = state_machine->states[i];
                for (int j = 0; j < state->num_next_states; j++) {
                    if (state->next_states[j] == state_to_delete) {
                        state->next_states[j] = NULL;
                    }
                }
            }
            // Shift the remaining states in the array
            int index_to_delete = state_to_delete->num_state;
            for (int i = index_to_delete; i < state_machine->num_states - 1; i++) {
                state_machine->states[i] = state_machine->states[i + 1];
                state_machine->states[i]->num_state = i;  // Update the index of the shifted state
            }
            state_machine->states[state_machine->num_states - 1] = NULL;
            free(state_to_delete);
            state_machine->num_states--;
        }
    }
    num_garbage = 0;
}

int main() {
    struct StateMachine* state_machine = create_state_machine();
    struct State* garbage[MAX_STATES];
    int num_garbage = 0;

    struct State* state_a = create_state("A");
    struct State* state_b = create_state("B");
    struct State* state_c = create_state("C");
    struct State* state_d = create_state("D");
    struct State* state_e = create_state("E");
    struct State* state_f = create_state("F");
    struct State* state_g = create_state("G");
    struct State* state_h = create_state("H");

    int stateNum = 0;
    state_a->num_state = stateNum++;
    state_b->num_state = stateNum++;
    state_c->num_state = stateNum++;
    state_d->num_state = stateNum++;
    state_e->num_state = stateNum++;
    state_f->num_state = stateNum++;
    state_g->num_state = stateNum++;
    state_h->num_state = stateNum++;

    add_next_state(state_a, state_f);
    add_next_state(state_a, state_e);
    add_next_state(state_b, state_b);
    add_next_state(state_b, state_c);
    add_next_state(state_c, state_h);
    add_next_state(state_c, state_d);
    add_next_state(state_d, state_e);
    add_next_state(state_d, state_g);
    add_next_state(state_e, state_g);
    add_next_state(state_e, state_b);
    add_next_state(state_f, state_b);
    add_next_state(state_f, state_a);
    add_next_state(state_g, state_a);
    add_next_state(state_g, state_h);
    add_next_state(state_h, state_d);
    add_next_state(state_h, state_f);

    add_state(state_machine, state_a);
    add_state(state_machine, state_b);
    add_state(state_machine, state_c);
    add_state(state_machine, state_d);
    add_state(state_machine, state_e);
    add_state(state_machine, state_f);
    add_state(state_machine, state_g);
    add_state(state_machine, state_h);

    state_machine->current_state = state_d;

    char command[10];
    char arg1[MAX_NAME_LENGTH];
    char arg2[MAX_NAME_LENGTH];
    printf("Starting State: %s\nEnter a command ('q' to quit): ", state_machine->current_state->name);
    while (scanf("%s", command) == 1) {
        if (strcmp(command, "0") == 0) { //strcmp is a standard library function in C that compares two strings and returns an integer value indicating their relative order. The function takes two string arguments and returns an integer value
            printf("%s\n", state_machine->current_state->next_states[0]->name);
            state_machine->current_state = state_machine->current_state->next_states[0];
        } else if (strcmp(command, "1") == 0) {
            printf("%s\n", state_machine->current_state->next_states[1]->name);
            state_machine->current_state = state_machine->current_state->next_states[1];
        } else if (strcmp(command, "c") == 0) {
            scanf("%s", arg1);
            scanf("%s", arg2);
            struct State* state = find_state(state_machine, arg2);
            if (strcmp(arg1, "0") == 0) {
                state_machine->current_state->next_states[0] = state;
            } else if (strcmp(arg1, "1") == 0) {
                state_machine->current_state->next_states[1] = state;
            }
        } else if (strcmp(command, "p") == 0) {
            for (int i = 0; i < state_machine->num_states; i++) {
                if (state_machine->states[i] != NULL && strcmp(state_machine->states[i]->name, "") != 0) {
                    printf("%s", state_machine->states[i]->name);
                    for (int j = 0; j < state_machine->states[i]->num_next_states; j++) {
                        printf(" %s", state_machine->states[i]->next_states[j]->name);
                    }
                    printf("\n");
                }
            }
        } else if (strcmp(command, "g") == 0) {
            num_garbage = identify_garbage_states_command(state_machine, garbage);
            if (num_garbage > 0) {
                printf("Garbage state(s): ");
                for (int i = 0; i < num_garbage; i++) {
                    printf("%s", garbage[i]->name);
                    if (i < num_garbage - 1) {
                        printf(", ");
                    }
                }
                printf("\n");
            } else if (num_garbage == 0) {
                printf("No Garbage\n");
            }
        } else if (strcmp(command, "d") == 0) {
            delete_state_command(state_machine, garbage, num_garbage);
        } else if (strcmp(command, "q") == 0) {
            printf("\nProgram Exited\n\n");
            exit(0);
        } else {
            printf("Invalid command\n");
        }
        printf("Enter a command ('q' to quit): ");
    }

    for (int i = 0; i < state_machine->num_states; i++) {
        free(state_machine->states[i]);
    }
    free(state_machine);

    return 0;
}  
